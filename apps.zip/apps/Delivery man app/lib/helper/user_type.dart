enum UserType {
  vendor,
  user,
  customer,
  // ignore: constant_identifier_names
  delivery_man
}
